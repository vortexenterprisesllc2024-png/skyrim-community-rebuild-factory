Honed Metal (Nexus 61015) SKSE plugin - source as rebuilt for Skyrim AE 1.7.104 / SKSE 2.3.1.
HonedMetal source: Nexus 61015 file 466884 "Source Code" v7 by a_retarded_monkey, plus the 1.26.1 getItemsCount / pluginVersion 8 compat patch (see BUILD-NOTES.md).
CMakeLists.txt + verify_version_block.py: the factory's wrapper (replaces the author's Visual Studio steps; see ReadMe.txt).
Built against: https://github.com/ianpatt/skse64 tag v2.3.1 (commit 7ff865f4a27d6dc936ab5fd0533ff2d706c8f857) as a static library (skse64.cpp excluded)
               https://github.com/ianpatt/common commit 64e233c096735551f6ac9a773726a8a3960e46cd (installed with cmake, prefix extern/)
Build: cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DCMAKE_PREFIX_PATH=<extern> -DSKSE64_ROOT=<skse64 checkout>
       cmake --build build --config Release --target HonedMetal      (VS 2022 v143, /MT)

Directories left out of this zip (unmodified, or build output): build

