import sys, struct, pefile
p = sys.argv[1]; data = open(p, 'rb').read(); pe = pefile.PE(data=data)
assert pe.FILE_HEADER.Machine == 0x8664, 'not x64'
exports = {e.name.decode(): e.address for e in pe.DIRECTORY_ENTRY_EXPORT.symbols if e.name}
assert 'SKSEPlugin_Load' in exports and 'SKSEPlugin_Version' in exports, exports
off = pe.get_offset_from_rva(exports['SKSEPlugin_Version']); blk = data[off:off + 0x350]
dataVersion, pluginVersion = struct.unpack_from('<II', blk, 0)
name = blk[8:264].split(b'\0')[0].decode(); author = blk[264:520].split(b'\0')[0].decode()
indepEx, indep = struct.unpack_from('<II', blk, 772); compat = struct.unpack_from('<16I', blk, 780)
print(f'name={name!r} author={author!r} pluginVersion={pluginVersion} versionIndependenceEx={indepEx:#x} versionIndependence={indep:#x} compatibleVersions={[hex(v) for v in compat if v]}')
crt = [i.dll.decode().lower() for i in pe.DIRECTORY_ENTRY_IMPORT]
print('imports:', crt)
assert name == 'HonedMetal', name
assert compat[0] == 0x01070680, 'compatibleVersions[0] is not 1.7.104.0'
assert indep == 0 and indepEx == 0, 'a classic SKSE plugin must not claim address-library independence'
assert not any(d.startswith(('vcruntime', 'msvcp', 'api-ms-win-crt')) for d in crt), 'expected /MT (static CRT)'
print('version block OK')
