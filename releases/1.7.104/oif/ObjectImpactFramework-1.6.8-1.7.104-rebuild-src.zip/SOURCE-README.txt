Object Impact Framework 1.6.8 (commit ec2b126b5fb0ae98311ceb30fc8acdf28d8936a2) as rebuilt for Skyrim AE 1.7.104 - corresponding source.
Upstream: https://github.com/arachnocid/ObjectImpactFramework (Apache-2.0)
This tree = upstream tag 1.6.8 + the patches listed in BUILD-NOTES.md (portfile REF/SHA512 bump, three one-line API fixes).
CommonLib is fetched by vcpkg from the overlay port in cmake/ports/commonlibsse-ng:
  https://github.com/alandtse/CommonLibVR commit d13d10a0ccb4945870eb841bf1ad8a6cf5ed84dd (branch ng, CommonLibSSE-NG 8.0.1, GPL-3.0-or-later with Modding Exception) - unmodified
  https://github.com/ValveSoftware/openvr commit ebdea152f8aac77e9a6db29682b81d762159df7e - unmodified headers
Build: cmake --preset AE ; cmake --build --preset AE   (VS 2022, vcpkg a1cae005c39be7b18ba319fced856b68d7276271, triplet x64-windows-static-md)

Directories left out of this zip (unmodified, or build output): .git, build, buildae, vcpkg_installed, openvr, tests, test_consumer, test_consumer_live, test_package, Flash

